/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrix;

import javax.swing.JOptionPane;

/**
 *
 * @author eveR
 */
public class Matrix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //declaraciones de variables
        String tamanio_str = null;
        int tamanio = 0;

        while (tamanio_str == null) {
            tamanio_str = JOptionPane
                    .showInputDialog("Ingrese el tamaño de las matrices a multiplicar");
        }

        tamanio = Integer.parseInt(tamanio_str);

        //creacion de matrices
        int A[][] = new int[tamanio][tamanio];
        int B[][] = new int[tamanio][tamanio];

        int filas = A.length;
        int columnas = A[0].length;

        // llenar matriz
        A = fillMatriz(filas, columnas);
        B = fillMatriz(filas, columnas);
        
        
        
        
        //mostrar
        showMatriz(A);
        showMatriz(B);
    }

    public static int[][] fillMatriz(int filas, int columnas) {
        int A[][] = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int num = Integer.parseInt(JOptionPane
                        .showInputDialog("Ingrese numero de la matriz A[" + i + "][" + j + "]"));
                A[i][j] = num;
                System.out.println(num + "");
            }
        }
        return A;
    }
    
    public static void showMatriz(int[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                JOptionPane.showMessageDialog(null, "dato guardado en la posicion A[" + i + "][" + j + "] = " + matriz[i][j]);
            }
        }
    }
}
